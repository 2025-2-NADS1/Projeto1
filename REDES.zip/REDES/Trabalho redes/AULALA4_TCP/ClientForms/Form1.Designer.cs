﻿namespace ClientForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtComando = new TextBox();
            TxtResposta = new TextBox();
            btnenviar = new Button();
            SuspendLayout();
            // 
            // txtComando
            // 
            txtComando.BackColor = SystemColors.Info;
            txtComando.Location = new Point(2, 12);
            txtComando.Name = "txtComando";
            txtComando.Size = new Size(470, 23);
            txtComando.TabIndex = 0;
            txtComando.Text = "GET DATE";
            // 
            // TxtResposta
            // 
            TxtResposta.BackColor = Color.Black;
            TxtResposta.ForeColor = Color.Lime;
            TxtResposta.Location = new Point(2, 53);
            TxtResposta.Multiline = true;
            TxtResposta.Name = "TxtResposta";
            TxtResposta.Size = new Size(628, 385);
            TxtResposta.TabIndex = 1;
            // 
            // btnenviar
            // 
            btnenviar.Location = new Point(478, 12);
            btnenviar.Name = "btnenviar";
            btnenviar.Size = new Size(75, 23);
            btnenviar.TabIndex = 2;
            btnenviar.Text = "enviar\r\n";
            btnenviar.UseVisualStyleBackColor = true;
            //btnenviar.Click += btnenviar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnenviar);
            Controls.Add(TxtResposta);
            Controls.Add(txtComando);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtComando;
        private TextBox TxtResposta;
        private Button btnenviar;
    }
}
